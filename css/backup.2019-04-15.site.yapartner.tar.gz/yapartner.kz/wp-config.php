<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'yapar_kz');

/** Имя пользователя MySQL */
define('DB_USER', 'u_yapar_kz');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'WWPuq8qX');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'aYW9iJ:3?L*2[6%>7[:M}0mkOW{WW!>.izGWnOuIm;-B9tHqj,h&c<x0e(g7%A.`');
define('SECURE_AUTH_KEY',  '444,fF6YF~;#c{[c^VxP#DY<2n:;8* Sm.U$b0F}a-Y}wG3I4|q@ u?!_ `ksID?');
define('LOGGED_IN_KEY',    't4mP&Jy@F2#P1t;R.D=%0(an$*wFeH]m@V<<zD@}l9g:+ l:s$AgBY>,n?&{vb{_');
define('NONCE_KEY',        'b+S=$=0SADCUU*Sm>UkM|Q4KfN`#H+t)]nB !N/;?~>UoS2D,CF1!qdT Eb{HtBK');
define('AUTH_SALT',        '~Z cS8x<]XF~<k4?qcRqK7RMypd$Z<s=<H1=r5+FiE7RcRZ|R,>TxyUbhtLjq90e');
define('SECURE_AUTH_SALT', '*t~%s/ZjQ*b1 bK4$K}-HsZXsK?Eeqg@]#g]kTuJRtfhWU5fI0Xx!{]w7d^g^jHD');
define('LOGGED_IN_SALT',   '8#}#L0zX$[seNb^ZQ*Vvw32SJT#wDqK55hk5.6^%b`PmIveh,X^Q/=HvHu.@4=$}');
define('NONCE_SALT',       '+%_D*;<B6OePDG}<m_I{_.`iC8,6]xVh **.g=GqUUo0-J^}&EFf3-QELn_TKC9Y');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'YT_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 * 
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);
define( 'WP_DEBUG_LOG', true );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
